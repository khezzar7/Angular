export class Produit {
    constructor(
        public name: string,
        public price: number,
        public url: string){
            this.name = name;
            this.price = price;
            this.url = url;
        };
}
