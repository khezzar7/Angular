import { Injectable } from '@angular/core';
import { Produit } from '../produit';

@Injectable({
  providedIn: 'root'
})
export class ProduitService {
  produits:any = [];
  connected: boolean;
  cart: any = [];
  constructor() { 
    this.produits = [
      new Produit('Power Rangers',23,'https://static.fnac-static.com/multimedia/Images/FR/MDM/a8/a3/38/3711912/1505-1/tsp20180712092620/Figurines-Power-Rangers-Ninja-Steel-30cm.jpg'),
      new Produit('Superwoman',45.56,'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Sergines-FR-89-carnaval_2017-carnavaleux-08.jpg/220px-Sergines-FR-89-carnaval_2017-carnavaleux-08.jpg'),
      new Produit('Batman',30,'https://upload.wikimedia.org/wikipedia/en/8/87/Batman_DC_Comics.png')
    ];
    this.connected = true;
    this.cart = [];
  }
  connexion(){
    this.connected = true;
  }
  deconnexion(){
    console.log('je deco ok')
    this.connected = false;
  }

  //Methode qui ajoute dans le panier
  panier(i):void{
    this.cart.push(this.produits[i]);
  }
} 
