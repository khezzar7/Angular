import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListeComponent } from './liste/liste.component';
import { CartComponent } from './cart/cart.component';
import { GestionComponent } from './gestion/gestion.component';
import { ProduitComponent } from './produit/produit.component';
import { RouterModule, Routes } from '@angular/router';


const appRoutes: Routes = [
  { path: 'gestion', component: GestionComponent},
  { path: 'liste', component: ListeComponent},
  { path: '', component: ListeComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    ListeComponent,
    CartComponent,
    GestionComponent,
    ProduitComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
