import { Component } from '@angular/core';
import { ProduitService } from './service/produit.service';
import { Produit } from './produit';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'produit';
  connected: boolean;
  constructor(private produitService:ProduitService){
    this.connected = this.produitService.connected;
  }
  connexion(){
    this.produitService.connexion();
    this.connected = this.produitService.connected;
  }
  deconnexion(){
    this.produitService.deconnexion();
    this.connected = this.produitService.connected;
  }
}
