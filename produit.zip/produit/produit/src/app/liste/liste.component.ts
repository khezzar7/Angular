import { Component, OnInit } from '@angular/core';
import { ProduitService } from '../service/produit.service';

@Component({
  selector: 'app-liste',
  templateUrl: './liste.component.html',
  styleUrls: ['./liste.component.css']
})
export class ListeComponent implements OnInit {

  connected: boolean;
  produits: any=[];
  constructor(private produitService: ProduitService) { 
    this.produits = this.produitService.produits;
    this.connected = this.produitService.connected;
  }

  panier(i:number):void{
    console.log(i)
    this.produitService.panier(i);
  }
  ngOnInit() {
  }

}
